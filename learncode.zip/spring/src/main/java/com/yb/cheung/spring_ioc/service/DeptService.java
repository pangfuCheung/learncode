package com.yb.cheung.spring_ioc.service;

import org.springframework.stereotype.Service;

@Service
public class DeptService {
}
