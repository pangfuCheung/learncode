package com.yb.cheung.spring_ioc.dao;

import org.springframework.stereotype.Repository;

@Repository
public class DeptDao {
}
