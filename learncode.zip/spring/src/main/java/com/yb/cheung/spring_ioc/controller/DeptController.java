package com.yb.cheung.spring_ioc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class DeptController {
}
