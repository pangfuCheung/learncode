package com.yb.cheung.spring_ioc.beans;

public class Teacher {

    public Teacher() {
        System.out.println("Teacher 的构造函数被调用。。。。。");
    }
}
