package com.yb.cheung.spring_ioc.beans;

import org.springframework.stereotype.Component;

@Component
public class Dept {
}
