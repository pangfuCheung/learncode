package com.yb.cheung.spring_ioc.beans;

public class Student {

    public Student() {

        System.out.println("Student 构造函数被调用。。。。。。");
    }
}
