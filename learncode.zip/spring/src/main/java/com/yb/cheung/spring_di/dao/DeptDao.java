package com.yb.cheung.spring_di.dao;

public class DeptDao {

	 public void save(){
		 System.out.println(this+" 添加数据库.....");
	 }
}
