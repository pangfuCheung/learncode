package com.yb.cheung.pattern.template;

public class Fu {

    public void method1(){
        System.out.println(" Fu method1 ...... ");
    }

    public void method2(){
        System.out.println(" Fu method2 ...... ");
    }

    public void method3(){
        System.out.println(" Fu method3 ...... ");
    }

    public void method4(){
        System.out.println(" Fu method4 ...... ");
    }

    public final void print(){

        method1();
        method2();
        method3();
        method4();

    }

}
