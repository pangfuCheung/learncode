package com.yb.cheung.pattern.template;

public class Zi extends Fu {

    @Override
    public void method1() {
        System.out.println(" Zi method1 ..... ");
    }
}
