package com.yb.cheung.pattern.template.test;

import com.yb.cheung.pattern.template.Zi;

public class TestMain {

    public static void main(String[] args) {

        Zi zi = new Zi();
        zi.print();

    }

}
