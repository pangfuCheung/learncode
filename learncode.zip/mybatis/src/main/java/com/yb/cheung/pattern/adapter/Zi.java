package com.yb.cheung.pattern.adapter;

public class Zi extends FuAdapter {

    public void zhuyaofangfa() {

        System.out.println("Zi zhuyaofangfa ......");
        super.method1();
        super.menthod2();
        super.method3();
    }
}
