package com.yb.cheung.pattern.adapter;

public interface Fu {

    public void zhuyaofangfa();

    public void method1();

    public void menthod2();

    public void method3();

}
