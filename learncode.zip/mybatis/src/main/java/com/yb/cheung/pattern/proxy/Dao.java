package com.yb.cheung.pattern.proxy;

public interface Dao {

    Integer getInteger();

    String getString();

}
