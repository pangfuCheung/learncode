package com.yb.cheung.pattern.mutilproxy.test;

import com.yb.cheung.pattern.mutilproxy.BaseDao;
import com.yb.cheung.pattern.mutilproxy.ProxyFactory;

public class TestMain {

    public static void main(String[] args) {
        /*BaseDao $proxy = (BaseDao) ProxyFactory.newInstanceProxy();
        $proxy.eat();*/



    }

}
