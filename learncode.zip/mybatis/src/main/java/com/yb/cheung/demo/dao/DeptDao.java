package com.yb.cheung.demo.dao;

import java.util.List;

public interface DeptDao {

    List findAll();

}
