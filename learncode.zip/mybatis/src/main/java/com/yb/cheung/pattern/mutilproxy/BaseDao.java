package com.yb.cheung.pattern.mutilproxy;

public interface BaseDao {

    void eat();

}
