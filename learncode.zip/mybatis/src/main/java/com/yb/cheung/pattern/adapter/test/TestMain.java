package com.yb.cheung.pattern.adapter.test;

import com.yb.cheung.pattern.adapter.Zi;

public class TestMain {

    public static void main(String[] args) {
        Zi zi = new Zi();
        zi.zhuyaofangfa();
    }

}
