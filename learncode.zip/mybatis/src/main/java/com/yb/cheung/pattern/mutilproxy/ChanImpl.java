package com.yb.cheung.pattern.mutilproxy;

public class ChanImpl implements BaseDao {

    public void eat() {
        System.out.println("蝉吃树枝。。。。。。");
    }
}
